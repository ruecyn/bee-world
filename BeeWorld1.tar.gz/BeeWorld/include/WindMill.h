#ifndef WINDMILL_H
#define WINDMILL_H


class WindMill
{
    public:

        WindMill();
        float x,y,z,cy;
        WindMill(float x,float y,float z,float cy,float angle);
        void render();
        //virtual ~WindMillBee();

    protected:

    private:

        float angle;
        void drawWindmill();
};

#endif // WINDMILL_H
