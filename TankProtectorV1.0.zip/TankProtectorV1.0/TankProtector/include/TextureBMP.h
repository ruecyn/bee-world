#ifndef TEXTUREBMP_H
#define TEXTUREBMP_H


class TextureBMP
{
    public:
        TextureBMP();
        virtual ~TextureBMP();
    protected:
    private:
};

#endif // TEXTUREBMP_H
