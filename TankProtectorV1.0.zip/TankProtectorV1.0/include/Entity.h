#ifndef ENTITY_H
#define ENTITY_H

struct position
{
    float x,y,z;
};

class Entity
{
    protected: // private field of entity
            position pos;    // Position of entity
            float Eradius;   // Entity radius
    public:
            // Constructor
            Entity(float x,float y,float z,float radius);
            virtual ~Entity();

            // Abstr Functions to be implemented on derived classes
            virtual void render();      // render entity
            virtual void update();      // update the state of entity

            // Functions of entity
            position getPosition();     // Get position of entity
            float getRadius();          // Get Collision radius of entity
};
#endif // ENTITY_H
