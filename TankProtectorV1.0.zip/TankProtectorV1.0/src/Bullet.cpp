#include "Bullet.h"
#include <math.h>
#include <GL/glut.h>
#define _Bradius_ 4

Bullet::Bullet(float x,float y,float z,float angle):MovableEntity(x,y,z,_Bradius_)
{
    this->angle = angle;
}

Bullet::Bullet()
{}

Bullet::~Bullet()
{
    alive = false;
}

void Bullet::update()
{
    float ab = M_PI * MovableEntity::angle/180.0;
    pos.x += 0.13*sin(ab);
    pos.z += 0.13*cos(ab);
}

void Bullet::render()
{
    glPushMatrix();
        glTranslatef(pos.x,pos.y,pos.z);
        glRotatef(angle,0,1,0);
        glTranslatef(0,0.3,3+0.6+0.9);
        glutSolidSphere(0.2,50,50);
    glPopMatrix();
}
