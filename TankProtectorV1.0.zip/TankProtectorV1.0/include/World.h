#ifndef WORLD_H
#define WORLD_H


class World
{
    public:
        // Constructor
        World();
        virtual ~World();
        void render();

    private:
        void drawWorld();
};

#endif // WORLD_H
