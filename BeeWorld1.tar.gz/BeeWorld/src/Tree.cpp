#include "Tree.h"

Tree::Tree()
{
    //ctor
}

Tree::~Tree()
{
    //dtor
}
