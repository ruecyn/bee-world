#include "Tank.h"
#include "MovableEntity.h"
#include <GL/glut.h>

#define _radius_ 1

Tank::Tank() : MovableEntity(0,0,0,0)
{}

Tank::Tank(float x, float y, float z,float angle) : MovableEntity(x,y,z,_radius_)
{
    this->angle=0.0;
    hit = 3;
}
void Tank::render()
{
    glPushMatrix();
        glTranslatef(pos.x, pos.y, pos.z-4); // Translation to tank position
        glRotatef(angle , 0,1,0); // Rotate to correspond to the camera
        //glTranslatef(0,0,4); //
        drawTank();
        drawCrossHair();
    glPopMatrix();
}

void Tank::move(float x,float z)
{
    pos.x += x;
    pos.z += z;
}

void Tank::turnTank(float angle)
{
    this->angle = angle;
}

float Tank::getX()
{
    return pos.x;
}

float Tank::getZ()
{
    return pos.z;
}

void Tank::drawTank()
{
    /*TANK TRANSLATION PUSH*/
    glPushMatrix();

        /*DRAW TOP PIECE OF TANK*/
        glPushMatrix();
        //TOP
            GLfloat yellowAmbient[] ={1,1,0};
            glMaterialfv(GL_FRONT,GL_DIFFUSE,yellowAmbient);
            glTranslatef(0,0.5,0);
            glutSolidCube(0.5);
        glPopMatrix();
        /*DRAW BASE OF TANK*/
        glPushMatrix();
            glScalef(1,0.5,1);
            glutSolidCube(1.0);
        glPopMatrix();

        /*DRAW CANNON*/
        glPushMatrix();
            glRotated(0,0,1,0);
            glTranslatef(0,0.6,-0.2);
            glScalef(1,1,3);
            GLUquadricObj *qobj = gluNewQuadric();
            gluCylinder(qobj,0.1,0.1,0.4,50,50);
        glPopMatrix();
    glPopMatrix();
}
void Tank::drawCrossHair(){
    /*DRAW CROSSHAIR*/
    glPushMatrix();
        glTranslatef(0,0.6,0.5);
        glColor3ub(255, 255, 0);
        glLineWidth(2.0);
        glBegin(GL_LINES);
            GLfloat redAmbient[] ={1,0,0};
            glMaterialfv(GL_FRONT,GL_DIFFUSE,redAmbient);
            glVertex2f(-0.1,0.6);
            glVertex2f(0.1,0.6);
            glVertex2f(0,0.7);
            glVertex2f(0,0.5);
        glEnd();
    glPopMatrix();
}
void Tank::update()
{
    glutPostRedisplay();
}
void Tank::shoot()
{   //glutSolidSphere(3,50,50);
//    shooter.shoot(pos.x,pos.y,pos.z,angle);
}

void Tank::kill()
{
    hit--;          // decrement hits as tank is killed
    if(hit == 0)
     alive = false;  // Tank die

}
