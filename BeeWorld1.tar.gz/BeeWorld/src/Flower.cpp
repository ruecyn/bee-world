#include "Flower.h"
//#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <GL/gl.h>
#include <stdlib.h>
#include <stdio.h>

Flower::Flower()
{
    //ctor
}
Flower::Flower(float x,float y,float z){
this->x=x;
this->y=y;
this->z=z;

}
void Flower::render(){

 for (int i = -3; i < 3; i++)
        for (int j = -3; j < 3; j++)
        {
         glPushMatrix();
         glTranslated(i*x,y,j*z);
         drawFlower();
         glPopMatrix();
        }

/*glTranslated(i * 10.0, 0, j * 10.0);*/

}
void Flower::drawFlower(){

//glLoadIdentity();                 // Reset the model-view matrix
GLUquadricObj*qd;
/*glClipPlane(GL_CLIP_PLANE1,clip_plane1);
glEnable(GL_CLIP_PLANE1);*/
// drawing a sphere
qd=gluNewQuadric();


glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(1.5f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.025f,0.025f,1.25f,15,15);
glPopMatrix();

//pink flower
//double clip_plane1[]={0.0,0.0,-1.0,0.5};
//glClipPlane(GL_CLIP_PLANE1,clip_plane1);
//glEnable(GL_CLIP_PLANE1);
glPushMatrix();
glTranslatef(1.5f, -1.0f, -7.0f);  // Move right and into the screen
glColor3f(1.0f,0.0f,1.0f);
gluSphere(qd,0.2f,30,30);
glPopMatrix();

glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(-1.5f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.025f,0.025f,1.25f,15,15);
glPopMatrix();

//green flower
glPushMatrix();
glTranslatef(-1.5f, -1.0f, -7.0f);  // Move right and into the screen
glColor3f(0.0f,1.0f,0.0f);
gluSphere(qd,0.2f,30,30);
glPopMatrix();

glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(-3.0f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.025f,0.025f,1.25f,15,15);
glPopMatrix();

//red flower
glPushMatrix();
glTranslatef(-3.0f, -1.0f, -7.0f);  // Move right and into the screen
glColor3f(1.0f,0.0f,0.0f);
gluSphere(qd,0.2f,30,30);
glPopMatrix();

glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(-1.0f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.025f,0.025f,1.25f,15,15);
glPopMatrix();
//yellow flower

glPushMatrix();
glTranslatef(-1.0f, -1.0f, -7.0f);  // Move right and into the screen
glColor3f(1.0f,1.0f,0.0f);
gluSphere(qd,0.2f,30,30);
glPopMatrix();

gluDeleteQuadric(qd);

   glutSwapBuffers();  // Swap the front and back frame buffers (double buffering)

}
