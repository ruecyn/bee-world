#include "Entity.h"

Entity::Entity(float x,float y,float z,float radius)
{
    // Initialize entity position
    pos.x = x;
    pos.y = y;
    pos.z = z;
    Eradius = radius;
}
Entity::~Entity()
{}

/* Get Position of the entity */
position Entity::getPosition()
{
    return pos;
}

/* Get collision radius of entity */
float Entity::getRadius()
{
    return Eradius;
}
