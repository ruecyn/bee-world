#ifndef STATICENTITY_H
#define STATICENTITY_H

#include <Entity.h>


class StaticEntity : public Entity
{
    public:
            // Constructors
            StaticEntity();
            StaticEntity(float x,float y,float z);
            virtual ~StaticEntity();


};

#endif // STATICENTITY_H
