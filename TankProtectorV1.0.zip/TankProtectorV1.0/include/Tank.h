#ifndef TANK_H
#define TANK_H
#include "MovableEntity.h"
//#include "Shooter"

class Tank : public MovableEntity
{
    public:
        // Constructor
        Tank();
        Tank(float x, float y,float z,float angle);

        // Function
        void move(float,float);  // Move Tank
        void turnTank(float angle);   // turn Tank
        float getX();
        float getZ();
        void shoot();                 // shoot the tank
        virtual void kill();          // kill this tank after 3 hits
        virtual void render();      // render entity
        virtual void update();      // update the state of entity
    private:
        // field
        int hit;
        // Private functions
        void drawTank();
        void drawCrossHair();
};

#endif // TANK_H
