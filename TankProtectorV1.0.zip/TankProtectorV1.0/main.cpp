#include "Entity.h"
#include "StaticEntity.h"
#include "MovableEntity.h"
#include "Bullet.h"
#include "Tank.h"
#include "World.h"
#include <GL/glut.h>
#include <vector>
#include <math.h>
#include <iostream>

#define _number_of_enemies_  10
#define _number_of_block_    10

using namespace std;

class Explode
{
#define NUM_PARTICLES    1000        /* Number of particles  */
#define NUM_DEBRIS       10           /* Number of debris     */
    int      wantNormalize = 0;   /* Speed vector normalization flag */
    int      wantPause = 0;       /* Pause flag */
    int      fuel = 0;                /* "fuel" of the explosion */

    struct particleData
    {
        float   position[3];
        float   speed[3];
        float   color[3];
    };
    typedef struct particleData    particleData;

    struct debrisData
    {
      float   position[3];
      float   speed[3];
      float   orientation[3];        /* Rotation angles around x, y, and z axes */
      float   orientationSpeed[3];
      float   color[3];
      float   scale[3];
    };
    typedef struct debrisData    debrisData;

    particleData     particles[NUM_PARTICLES];
    debrisData       debris[NUM_DEBRIS];

  public:
  Explode(){}

 void newSpeed (float dest[3])
{
  float    x;
  float    y;
  float    z;
  float    len;

  x = (2.0 * ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
  y = (2.0 * ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
  z = (2.0 * ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;

  /*
   * Normalizing the speed vectors gives a "fireball" effect
   *
   */

  if (wantNormalize)
    {
      len = sqrt (x * x + y * y + z * z);

      if (len)
	{
	  x = x / len;
	  y = y / len;
	  z = z / len;
	}
    }

  dest[0] = x;
  dest[1] = y;
  dest[2] = z;
}

 void render()
 {
    int i;
      glPushMatrix ();

      glDisable (GL_LIGHTING);
      glDisable (GL_DEPTH_TEST);

      glBegin (GL_POINTS);

      for (i = 0; i < NUM_PARTICLES; i++)
	{
	  glColor3fv (particles[i].color);
	  glVertex3fv (particles[i].position);
	}

      glEnd ();

      glPopMatrix ();

      glEnable (GL_LIGHTING);
      glEnable (GL_LIGHT0);
      glEnable (GL_DEPTH_TEST);

      glNormal3f (0.0, 0.0, 1.0);

      for (i = 0; i < NUM_DEBRIS; i++)
	{
	  glColor3fv (debris[i].color);

	  glPushMatrix ();

	  glTranslatef (debris[i].position[0],
			debris[i].position[1],
			debris[i].position[2]);

	  glRotatef (debris[i].orientation[0], 1.0, 0.0, 0.0);
	  glRotatef (debris[i].orientation[1], 0.0, 1.0, 0.0);
	  glRotatef (debris[i].orientation[2], 0.0, 0.0, 1.0);

	  glScalef (debris[i].scale[0],
		    debris[i].scale[1],
		    debris[i].scale[2]);

	  glBegin (GL_TRIANGLES);
	  glVertex3f (0.0, 0.5, 0.0);
	  glVertex3f (-0.25, 0.0, 0.0);
	  glVertex3f (0.25, 0.0, 0.0);
	  glEnd ();

	  glPopMatrix ();
	}
 }

 void newExplosion (float x,float y,float z)
 {
  int    i;

  for (i = 0; i < NUM_PARTICLES; i++)
    {
      particles[i].position[0] = x;
      particles[i].position[1] = y;
      particles[i].position[2] = z;

      particles[i].color[0] = 1.0;
      particles[i].color[1] = 1.0;
      particles[i].color[2] = 0.5;

      newSpeed (particles[i].speed);
    }

  for (i = 0; i < NUM_DEBRIS; i++)
    {
      debris[i].position[0] = x;
      debris[i].position[1] = y;
      debris[i].position[2] = z;

      debris[i].orientation[0] = 0.0;
      debris[i].orientation[1] = 0.0;
      debris[i].orientation[2] = 0.0;

      debris[i].color[0] = 0.7;
      debris[i].color[1] = 0.7;
      debris[i].color[2] = 0.7;

      debris[i].scale[0] = (2.0 *
			    ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
      debris[i].scale[1] = (2.0 *
			    ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
      debris[i].scale[2] = (2.0 *
			    ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;

      newSpeed (debris[i].speed);
      newSpeed (debris[i].orientationSpeed);
    }
  fuel = 100;

}

  void update(void)
  {
  int    i;

  if (!wantPause)
    {
      if (fuel > 0)
	{
	  for (i = 0; i < NUM_PARTICLES; i++)
	    {
	      particles[i].position[0] += particles[i].speed[0] * 0.2;
	      particles[i].position[1] += particles[i].speed[1] * 0.2;
	      particles[i].position[2] += particles[i].speed[2] * 0.2;

	      particles[i].color[0] -= 1.0 / 500.0;
	      if (particles[i].color[0] < 0.0)
		{
		  particles[i].color[0] = 0.0;
		}

	      particles[i].color[1] -= 1.0 / 100.0;
	      if (particles[i].color[1] < 0.0)
		{
		  particles[i].color[1] = 0.0;
		}

	      particles[i].color[2] -= 1.0 / 50.0;
	      if (particles[i].color[2] < 0.0)
		{
		  particles[i].color[2] = 0.0;
		}
	    }

	  for (i = 0; i < NUM_DEBRIS; i++)
	    {
	      debris[i].position[0] += debris[i].speed[0] * 0.1;
	      debris[i].position[1] += debris[i].speed[1] * 0.1;
	      debris[i].position[2] += debris[i].speed[2] * 0.1;

	      debris[i].orientation[0] += debris[i].orientationSpeed[0] * 10;
	      debris[i].orientation[1] += debris[i].orientationSpeed[1] * 10;
	      debris[i].orientation[2] += debris[i].orientationSpeed[2] * 10;
	    }

	  --fuel;
	}

  glutPostRedisplay ();
}


}
}explode;

/* Game Variables */
World earth;                                   // God first created Earth
StaticEntity blocks[_number_of_block_];        // then Static entities like blocks,tree,etc
Tank player;                                   // then me and you as Tank
//Tank enemies[_number_of_enemies_];             // then haters as enemies
Bullet bullets[_number_of_enemies_];                        // then bullets to kill each other
int bcount =0;

float a,lx, ly, lz;      // Used to move and turn the camera
float z_dist_at =5.0;
float turn_inc  =0.5;
float angle = 0;
bool exploding = false;

float camera[3][3] = {{0, 0, -z_dist_at},
                      {0, 0, 0},{0, 1, 0}
                     };


/* Create new bullet */
void shoot(float x,float y,float z,float angle)
{
    if(bcount < _number_of_enemies_)
      bullets[bcount++] = Bullet(x,y,z,angle);

}

bool withinWorld(float x, float z)
{
    return (x > -97 && x < 97) &&
           (z > -97 && z < 97);
}

/* update bullets movements */
void updateShooting()
{
    for(int i =0; i < bcount ; i++)
    {
        if(bullets[i].isAlive())
        {
             bullets[i].update();
            for(int j = 0; j < _number_of_block_; j++)
                if(bullets[i].checkCollision(&blocks[j]) || !withinWorld(bullets[i].getPosition().x,bullets[i].getPosition().z))
                {
                    bullets[i].kill();
                    explode.newExplosion(bullets[i].getPosition().x, bullets[i].getPosition().y, bullets[i].getPosition().z);
                    exploding = true;
                }
        }
    }

}

bool collisionDetectionPlayer()
{
     for(int j = 0; j < _number_of_block_; j++)
            if(player.checkCollision(&blocks[j]))
                return true;
    // for(int j = 0; j < _number_of_enemies_; j++)
   //         if(player.checkCollision(&enemies[j]))
     //           return true;
    return false;
}

void resetCamera()
{
		angle = 0;
		lx=0;
		lz=z_dist_at;
		camera[0][2] = -z_dist_at;
}

/* Initialize OpenGL Graphics */
void initGL()
{
   // Set "clearing" or background color
    glClearColor(0, 0.7, 1, 1); // White and opaque
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST); // turns on hidden surface removal so that objects behind other objects do not get displayed

    resetCamera();

    earth = World(); // Construct earth
    player = Tank(camera[0][0],camera[0][1],camera[0][2]+7,angle);
    //bullets = vector<Bullet>();


     blocks[0]  = StaticEntity(0,0,20);
     blocks[1]  = StaticEntity(20,0,60);
     blocks[2]  = StaticEntity(30,0,40);
     blocks[3]  = StaticEntity(-11,0,3);
     blocks[4]  = StaticEntity(-13,0,5);
     blocks[5]  = StaticEntity(15,0,5);
     blocks[6]  = StaticEntity(-17,0,5);
     blocks[7]  = StaticEntity(13,0,7);
     blocks[8]  = StaticEntity(-13,0,9);
     blocks[9]  = StaticEntity(13,0,11);

    /* Create haters of the earth
    enemies.push_back(Tank(100,0,20,0));
    enemies.push_back(Tank(90,0,5,0));
    enemies.push_back(Tank(10,0,70,0)); */
}

/* Set the eye of ...... think for yourself */
void setCamera()
{
    gluLookAt(camera[0][0], 1.5, camera[0][2],
              camera[1][0], camera[1][1], camera[1][2],
              camera[2][0], camera[2][1], camera[2][2] );
}

/* render the world */
void render() {

    // GL_DEPTH_BUFFER_BIT - resets the depth test values for hidden surface removal
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Reset transformations
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    // Set the camera
    setCamera();

    //draw world
    earth.render();

    player.render();

    for(int i = 0; i < _number_of_block_; i++)
        blocks[i].render();

    //for(int i = 0; _number_of_enemies_; i++)
     //   enemies[i].render();

    for(int i = 0; i < bcount; i++)
        if(bullets[i].isAlive())
            bullets[i].render();

    if(exploding)
    {
      explode.render();
    }

    glFlush();   // Render now
}
void update()
{
    if(exploding)
        explode.update();
    glutPostRedisplay();
}

void processNormalKeys(unsigned char key, int x, int y) {

	switch (key) {
		case 27 :  exit(0); break;
		case ' ':  shoot(camera[0][0],camera[0][1],camera[0][2],angle); break;
    }
    update();
}

void turn(int dir)
{
          float  Dangle =angle;
          float  Da = a;
		  float	 Dlx = lx;
          float  Dlz = lz;
		  float	 Dcamera0=camera[1][0];
		  float	 Dcamera2=camera[1][2];


        if(dir ==-1)
        {
            angle += turn_inc;
			a = M_PI*angle/180.0;
			lx = z_dist_at *sin(a);
			lz = z_dist_at *cos(a);
			camera[1][0]=camera[0][0]+lx;
			camera[1][2]=camera[0][2]+lz;
			player.turnTank(angle);
        }
        else
        {
            angle -= turn_inc;
			a = M_PI*angle/180.0;
			lx = z_dist_at *sin(a);
			lz = z_dist_at *cos(a);
			camera[1][0]=camera[0][0]+lx;
			camera[1][2]=camera[0][2]+lz;
			player.turnTank(angle);
        }


       if(collisionDetectionPlayer())
        {
            angle =Dangle;
            a = Da;
            lx = Dlx;
            lz = Dlz;
            camera[0][0]=Dcamera0;
		    camera[0][2]=Dcamera2;
            player.turnTank(angle);
        }


}

void movement(int dir)
{
        float x,z;

            float Da =  a;
        	float camera00 = camera[0][0]; // move x by
            float camera02 = camera[0][2];
        	float camera10 = camera[1][0]; // move x by
            float camera12 = camera[1][2];
            float returnx  = player.getX();
            float returnz  = player.getZ();

            if(dir == 1)
            {
                a = M_PI*angle/180.0;
                x =  sin(a);
                z = cos(a);
                camera[0][0] += x; // move x by
                camera[0][2] += z;
                camera[1][0] += x; // move x by
                camera[1][2] += z;
                player.move(x,z);
               // xCord += x;
               // zCord += z;
            }
            else
            {
                a = M_PI*angle/180.0;
			    x =  sin(a);
			    z = cos(a);
                camera[0][0] -= x; // move x by
                camera[0][2] -= z;
                camera[1][0] -= x; // move x by
                camera[1][2] -= z;
                player.move(-x,-z);
            }

        if(collisionDetectionPlayer() || !withinWorld(player.getX(),player.getZ()))
        {
                  a =  Da;
            camera[0][0] = camera00; // move x by
            camera[0][2] = camera02;
            camera[1][0] = camera10; // move x by
            camera[1][2] = camera12;

            player.setPosition(returnx,player.getPosition().y,returnz);
        }

}
void inputKey(int key, int ix, int iy) {

	switch (key) {
		case GLUT_KEY_LEFT : turn(-1);
            break;
		case GLUT_KEY_RIGHT : turn(1);
		    break;
		case GLUT_KEY_UP : movement(1);
		    break;
		case GLUT_KEY_DOWN :movement(-1);
            break;
	}

    glutPostRedisplay();
}




/* Handler for window re-size event. Called back when the window first appears and
   whenever the window is re-sized with its new width and height */
void reshape(int w, int h)
{

    // Prevent a divide by zero, when window is too short
    // (you cant make a window of zero width).
    if(h == 0)	h = 1;

    GLfloat ratio = 1.0f * (GLfloat)w / (GLfloat)h;

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);

    // Reset the coordinate system before modifying
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Set the clipping volume
    gluPerspective(45, ratio, 0.1, 1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
//Time callback
void timeFunc(int value)
{
    updateShooting();
    update();
    glutTimerFunc(5,timeFunc,1);
}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv)
{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(640, 480);   // Set the window's initial width & height - non-square
    glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
    glutCreateWindow("Model Transform");  // Create window with the given title

    initGL();                       // Our own OpenGL initialization

    glutDisplayFunc(render);       // Register callback handler for window re-paint event
    glutIdleFunc(update);
    glutReshapeFunc(reshape);       // Register callback handler for window re-size event
    glutTimerFunc(5,timeFunc,1);

	glutKeyboardFunc(processNormalKeys); //Register callback handler for keyboard input normal keys
	glutSpecialFunc(inputKey);          //Register callback handler for keyboard input special keys
    glutMainLoop();                 // Enter the infinite event-processing loop
    return 0;
}

