#ifndef BULLET_H
#define BULLET_H

#include <MovableEntity.h>


class Bullet : public MovableEntity
{
    public:
            // Constructor
            Bullet(float x,float y,float z,float angle);
            virtual ~Bullet();
            Bullet();

            // Functions
            virtual void render();      // render entity
            virtual void update();      // update the state of entity

    private:
};

#endif // BULLET_H
