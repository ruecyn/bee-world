#ifndef SNOWMAN_H
#define SNOWMAN_H
#include "Collision.h"
//#include "RenderableObject.h"

class Snowman
{
    public:
       // Snowman(float id, Location& location,float p_radius, float speed );
       // Snowman(float id, Location& location, float p_radius, float speed, int* colour);
       float x,y,z,radius,radius2;
        Snowman();
        Snowman(float x,float y,float z,float radius,float radius2);

       // void update();
        void render();
        void moveBeeLeft();
        void moveBeeRight();
        void moveBeeUp();
        void moveBeeDown();
        void moveBeeForward();
        void moveBeeBackward();
    private:

        void drawSnowman();


};

#endif // SNOWMAN_H
