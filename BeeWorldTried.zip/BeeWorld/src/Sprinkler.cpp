#include "Sprinkler.h"
#include <GL/glut.h>		//includes gl.h and glu.h
#include <stdlib.h>			//random function
#include <math.h>			//sine and cosine functions
#define PI 3.1415265359
#define RandomFactor 2.0	//cannot be variable, because it is only use in InitFountain(),

GLint ListNum;  //The number of the diplay list

struct SVertex
{
	GLfloat x,y,z;
};

class CDrop
{
private:
	GLfloat time;          //How many steps the drop was "outside", when it falls into the water, time is set back to 0
	SVertex ConstantSpeed;  //See the doc for explanation of the physics
	GLfloat AccFactor;
public:
	void SetConstantSpeed (SVertex NewSpeed);
	void SetAccFactor(GLfloat NewAccFactor);
	void SetTime(GLfloat NewTime);
	void GetNewPosition(SVertex * PositionVertex);  //increments time, gets the new position
};

void CDrop::SetConstantSpeed(SVertex NewSpeed)
{
	ConstantSpeed = NewSpeed;
}

void CDrop::SetAccFactor (GLfloat NewAccFactor)
{
	AccFactor = NewAccFactor;
}

void CDrop::SetTime(GLfloat NewTime)
{
	time = NewTime;
}

void CDrop::GetNewPosition(SVertex * PositionVertex)
{
	SVertex Position;
	time += 1.0;
	Position.x = ConstantSpeed.x * time;
	Position.y = ConstantSpeed.y * time - AccFactor * time * time;
	Position.z = ConstantSpeed.z * time;
	PositionVertex->x = Position.x;
	PositionVertex->y = Position.y;
	PositionVertex->z = Position.z;
	if (Position.y < 0.0)
	{
		time = time - int(time);
		if (time > 0.0) time -= 1.0;
	}
}

CDrop * SprinklerDroplets;
SVertex * SprinklerVert;
GLint Movements = 3;   //a fountain has several steps, each with its own height
GLint RaysPerM = 20;
GLint DropsPerM = 50;
int Droplets = Movements * RaysPerM * DropsPerM;
GLfloat AngleOfMovement = 80;
GLfloat AccFactor = 0.011;
Sprinkler::Sprinkler()
{
    //ctor
}

void CreateList(void)
{
	GLuint ID;

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glGenTextures(1,&ID);
	glBindTexture( GL_TEXTURE_2D, ID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	ListNum = glGenLists(1);

	glNewList(ListNum, GL_COMPILE);

		//The "water":
		glTranslatef(0.0,0.45, 0.0);
		glBindTexture(GL_TEXTURE_2D, ID);
		glEnable(GL_TEXTURE_2D);

		glDisable(GL_TEXTURE_2D);

	glEndList();
}

GLfloat GetRandomFloat(GLfloat range)
{
	return (GLfloat)rand() / (GLfloat)RAND_MAX * range * RandomFactor;
}

void InitFountain(void)
{
	//This function needn't be and isn't speed optimized
    SprinklerDroplets = new CDrop [ Droplets ];
	SprinklerVert = new SVertex [ Droplets ];
	SVertex NewSpeed;
	GLfloat DropAccFactor; //different from AccFactor because of the random change
	GLfloat TimeNeeded;
	GLfloat StepAngle; //Angle, which the ray gets out of the fountain with
	GLfloat RayAngle;	//Angle you see when you look down on the fountain
	GLint i,j,k;
	for (k = 0; k <1; k++)
	{
		for (j = 0; j < RaysPerM; j++)
		{
			for (i = 0; i < DropsPerM; i++)
			{
				DropAccFactor = AccFactor + GetRandomFloat(0.0005);
				StepAngle = AngleOfMovement + (90.0-AngleOfMovement)
						* GLfloat(k) / (2) + GetRandomFloat(0.2+0.8*(2-k)/(2));
				//This is the speed caused by the step:
				NewSpeed.x = cos ( StepAngle * PI / 20.0) * (0.2+0.04*k);
				NewSpeed.y = sin ( StepAngle * PI / 180.0) * (0.2+0.04*k);
				//This is the speed caused by the ray:

				RayAngle = (GLfloat)j / (GLfloat)RaysPerM * 360.0;
				//for the next computations "NewSpeed.x" is the radius. Care! Dont swap the two
				//lines, because the second one changes NewSpeed.x!
				NewSpeed.z = NewSpeed.x * sin ( RayAngle * PI /180.0);
				NewSpeed.x = NewSpeed.x * cos ( RayAngle * PI /180.0);

				//Calculate how many steps are required, that a drop comes out and falls down again
				TimeNeeded = NewSpeed.y/ DropAccFactor;
				SprinklerDroplets[i+j*DropsPerM+k*DropsPerM*RaysPerM].SetConstantSpeed ( NewSpeed );
				SprinklerDroplets[i+j*DropsPerM+k*DropsPerM*RaysPerM].SetAccFactor (DropAccFactor);
				SprinklerDroplets[i+j*DropsPerM+k*DropsPerM*RaysPerM].SetTime(TimeNeeded * i / DropsPerM);
			}
		}
	}

	glEnableClientState(GL_VERTEX_ARRAY);
	//Pass the date position
	glVertexPointer(	3,			//x,y,z-components
						GL_FLOAT,	//data type of SVertex
						0,			//the vertices are tightly packed
						SprinklerVert);
}

void DrawSprinkler(void)
{
	glColor4f(0.8,0.8,0.8,0.8);
	for (int i = 0; i < Droplets; i++)
	{
		SprinklerDroplets[i].GetNewPosition(&SprinklerVert[i]);
	}
	glDrawArrays(	GL_POINTS,
					0,
					Droplets);
}


void Displayy(void)
{


	 for (int i = -3; i < 3; i++)
        for (int j = -3; j < 3; j++)
        {
        glPushMatrix();
		glCallList(ListNum);
		glTranslated(i * 8.0, 0, j * 8.0);
		DrawSprinkler();
	    glPopMatrix();
        }


}
