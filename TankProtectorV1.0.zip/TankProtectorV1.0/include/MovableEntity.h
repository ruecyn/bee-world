#ifndef MOVABLEENTITY_H
#define MOVABLEENTITY_H

#include <Entity.h>


class MovableEntity : public Entity
{
    protected:
            // Field of movable entity
            float angle;      // angle where movable entity point to
            bool alive;       // Life of movable entity
    public:
            // Constructor
            MovableEntity(float x,float y,float z,float r);
            MovableEntity();
            virtual ~MovableEntity();

            // Functions
            bool checkCollision(Entity *e);         // Check if Entity collide with Entity e
            bool isAlive();                         // is entity alive
            void born();                            // make entity live
            virtual void kill();                    // kill this entity
            void setPosition(float,float,float);    // set new Position of movable entity


};

#endif // MOVABLEENTITY_H
