# 3D-House-using-OpenGL-and-C-
Basic texture implementation example.
