#include "StaticEntity.h"
#include <GL/glut.h>
#define _Bradius_ 2

StaticEntity::StaticEntity(float x,float y,float z) : Entity(x,y,z,_Bradius_)
{}

StaticEntity::StaticEntity():Entity(0,0,0,_Bradius_)
{}

StaticEntity::~StaticEntity()
{}

/* render block */
void Entity::render()
{
     glPushMatrix();
      glTranslated(pos.x,pos.y,pos.z);
      glutSolidCube(4);
  glPopMatrix();

}

void Entity::update()
{
    // Nothing to update it static entity
}
