#include "Bullet.h"

Bullet::Bullet()
{
    //ctor
}

Bullet::~Bullet()
{
    //dtor
}
