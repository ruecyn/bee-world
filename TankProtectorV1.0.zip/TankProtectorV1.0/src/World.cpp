#include "World.h"
#include <GL/glut.h>

GLfloat  light0Amb[4] =  { 1.0, 0.6, 0.2, 1.0 };
GLfloat  light0Dif[4] =  { 1.0, 0.6, 0.2, 1.0 };
GLfloat  light0Spec[4] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat  light0Pos[4] =  { 0.0, 0.0, 0.0, 1.0 };

GLfloat  light1Amb[4] =  { 0.0, 0.0, 0.0, 1.0 };
GLfloat  light1Dif[4] =  { 1.0, 1.0, 1.0, 1.0 };
GLfloat  light1Spec[4] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat  light1Pos[4] =  { 0.0, 5.0, 5.0, 0.0 };

GLfloat  materialAmb[4] = { 0.25, 0.22, 0.26, 1.0 };
GLfloat  materialDif[4] = { 0.63, 0.57, 0.60, 1.0 };
GLfloat  materialSpec[4] = { 0.99, 0.91, 0.81, 1.0 };
GLfloat  materialShininess = 27.8; /* Shine bright like a diamond */

World::World()
{
  glEnable (GL_LIGHT0);
  glEnable (GL_LIGHT1);
  glLightfv (GL_LIGHT0, GL_AMBIENT, light0Amb);
  glLightfv (GL_LIGHT0, GL_DIFFUSE, light0Dif);
  glLightfv (GL_LIGHT0, GL_SPECULAR, light0Spec);
  glLightfv (GL_LIGHT0, GL_POSITION, light0Pos);
  glLightfv (GL_LIGHT1, GL_AMBIENT, light1Amb);
  glLightfv (GL_LIGHT1, GL_DIFFUSE, light1Dif);
  glLightfv (GL_LIGHT1, GL_SPECULAR, light1Spec);
  glLightfv (GL_LIGHT1, GL_POSITION, light1Pos);
  glLightModelf (GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
  glMaterialfv (GL_FRONT_AND_BACK, GL_AMBIENT, materialAmb);
  glMaterialfv (GL_FRONT_AND_BACK, GL_DIFFUSE, materialDif);
  glMaterialfv (GL_FRONT_AND_BACK, GL_SPECULAR, materialSpec);
  glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, materialShininess);
  glEnable (GL_NORMALIZE);


}
World::~World()
{}

void World::render()
{
    drawWorld();
}

void World::drawWorld(){
        /*WORLD PUSH*/
        glPushMatrix();

                  float grayAmbient[] ={0.5,0.5,0.5};
                  glMaterialfv(GL_FRONT,GL_DIFFUSE,grayAmbient);
                  glColor3ub( 0, 64,  0); // green
                  glBegin(GL_QUADS);
                  glVertex3f(-100.0f, -2.0f, -100.0f);
                  glVertex3f(-100.0f, -2.0f, 100.0f);
                  glVertex3f(100.0f, -2.0f, 100.0f);
                  glVertex3f(100.0f, -2.0f, -100.0f);
                  glEnd();
        glPopMatrix();

        glPushMatrix();
          glMaterialfv(GL_FRONT,GL_DIFFUSE,grayAmbient);
          //glColor3ub((byte) 0, (byte) 64, (byte) 0); // green
          glBegin(GL_QUADS);
          glVertex3f(-100.0f, -2.0f, -100.0f);
          glVertex3f(-100.0f, -2.0f, 100.0f);
          glVertex3f(100.0f, -2.0f, 100.0f);
          glVertex3f(100.0f, -2.0f, -100.0f);
          glEnd();
      glPopMatrix();

      /*DRAW WALL AT <0,0.15,102>    */
      float greenAmbient[] ={0.0,0.5,0.0};
          glPushMatrix();
            glMaterialfv(GL_FRONT,GL_DIFFUSE,greenAmbient);
            glScaled(50,3,1);
              glTranslated(0,1.3,102);
             glutSolidCube(4);
          glPopMatrix();


       /*DRAW wall AT <0,1.5,-102>    */
       glPushMatrix();
        //GLfloat yellowAmbient[] ={0.5,0.0,0.0};
      glMaterialfv(GL_FRONT,GL_DIFFUSE,greenAmbient);
            glScaled(50,3,1);
              glTranslated(0,1.3,-102);
             glutSolidCube(4);
        glPopMatrix();


      /*DRAW wall AT <102,1.5,0>    */
       glPushMatrix();
        //GLfloat yellowAmbient[] ={0.5,0.0,0.0};
      glMaterialfv(GL_FRONT,GL_DIFFUSE,greenAmbient);
            glScaled(1,3,50);
              glTranslated(102,1.3,0);
             glutSolidCube(4);
        glPopMatrix();


       /*DRAW wall AT <-102,1.5,0>    */
       glPushMatrix();
        //GLfloat yellowAmbient[] ={0.5,0.0,0.0};
      glMaterialfv(GL_FRONT,GL_DIFFUSE,greenAmbient);
            glScaled(1,3,50);
              glTranslated(-102,1.3,0);
             glutSolidCube(4);
        glPopMatrix();

}


