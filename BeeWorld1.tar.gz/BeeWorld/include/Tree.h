#ifndef TREE_H
#define TREE_H


class Tree
{
    public:
        Tree();
        virtual ~Tree();
    protected:
    private:
};

#endif // TREE_H
