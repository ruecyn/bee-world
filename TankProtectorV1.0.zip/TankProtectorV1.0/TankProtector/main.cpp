
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <iostream>
#include<math.h>

#include<vector>
#include"RgbImage.h"

using namespace std;


GLfloat yellowAmbient[] ={1,1,0};
//GLfloat grayAmbient[] ={0.5,0.5,0.5};
//GLfloat redAmbient[] ={0.5,0.0,0.0};
GLfloat wallAmbient[] ={0.5,0.35,0.05};
void renderBitMapString(float x,float y,float z, void *font,string str)
{

    glRasterPos3f(x,y,z);
    for(int i = 0; i < str.length();i++)
    {
        glutBitmapCharacter(font,str[i]);
    }
}

void loadTextureFromFile(char *filename)
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
	glEnable(GL_DEPTH_TEST);

	RgbImage theTexMap( filename );

	// Pixel alignment: each row is word aligned (aligned to a 4 byte boundary)
	//    Therefore, no need to call glPixelStore( GL_UNPACK_ALIGNMENT, ... );

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	gluBuild2DMipmaps(GL_TEXTURE_2D, 3,theTexMap.GetNumCols(), theTexMap.GetNumRows(),
					 GL_RGB, GL_UNSIGNED_BYTE, theTexMap.ImageData() );

}

static void
drawBox(GLfloat size, GLenum type)
{
   glEnable(GL_TEXTURE_2D);
   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);


  static GLfloat n[6][3] =
  {
    {-1.0, 0.0, 0.0},
    {0.0, 1.0, 0.0},
    {1.0, 0.0, 0.0},
    {0.0, -1.0, 0.0},
    {0.0, 0.0, 1.0},
    {0.0, 0.0, -1.0}
  };
  static GLint faces[6][4] =
  {
    {0, 1, 2, 3},
    {3, 2, 6, 7},
    {7, 6, 5, 4},
    {4, 5, 1, 0},
    {5, 6, 2, 1},
    {7, 4, 0, 3}
  };
  GLfloat v[8][3];
  GLint i;

  v[0][0] = v[1][0] = v[2][0] = v[3][0] = -size / 2;
  v[4][0] = v[5][0] = v[6][0] = v[7][0] = size / 2;
  v[0][1] = v[1][1] = v[4][1] = v[5][1] = -size / 2;
  v[2][1] = v[3][1] = v[6][1] = v[7][1] = size / 2;
  v[0][2] = v[3][2] = v[4][2] = v[7][2] = -size / 2;
  v[1][2] = v[2][2] = v[5][2] = v[6][2] = size / 2;

  for (i = 5; i >= 0; i--) {
    glBegin(type);
    glNormal3fv(&n[i][0]);
    glTexCoord2f(0.0, 0.0);
    glVertex3fv(&v[faces[i][0]][0]);
     glTexCoord2f(0.0, 1.0);
    glVertex3fv(&v[faces[i][1]][0]);
    glTexCoord2f(1.0, 1.0);
    glVertex3fv(&v[faces[i][2]][0]);
    glTexCoord2f(1.0, 0.0);
    glVertex3fv(&v[faces[i][3]][0]);
    glEnd();
  }



  glDisable(GL_TEXTURE_2D);
}

void APIENTRY
glutSolidCube2(GLdouble size)
{
  drawBox(size, GL_QUADS);
}

class World
{
    public :
    World()
    {

    }


    void drawWorld()
    {
        /*WORLD PUSH*/
        glPushMatrix();

                  GLfloat grayAmbient[] ={0.5,0.5,0.5};
                  glMaterialfv(GL_FRONT,GL_DIFFUSE,grayAmbient);
                  glColor3ub( 0, 64,  0); // green
                  glBegin(GL_QUADS);
                  glVertex3f(-100.0f, -2.0f, -100.0f);
                  glVertex3f(-100.0f, -2.0f, 100.0f);
                  glVertex3f(100.0f, -2.0f, 100.0f);
                  glVertex3f(100.0f, -2.0f, -100.0f);
                  glEnd();
        glPopMatrix();

        glPushMatrix();
          glMaterialfv(GL_FRONT,GL_DIFFUSE,grayAmbient);
          //glColor3ub((byte) 0, (byte) 64, (byte) 0); // green
          glBegin(GL_QUADS);
          glVertex3f(-100.0f, -2.0f, -100.0f);
          glVertex3f(-100.0f, -2.0f, 100.0f);
          glVertex3f(100.0f, -2.0f, 100.0f);
          glVertex3f(100.0f, -2.0f, -100.0f);
          glEnd();
      glPopMatrix();

      /*DRAW WALL AT <0,0.15,102>    */

          glPushMatrix();
            glMaterialfv(GL_FRONT,GL_DIFFUSE,wallAmbient);
              glScaled(50,3,1);
              glTranslated(0,1.3,102);
             glutSolidCube2(4);
          glPopMatrix();


       /*DRAW wall AT <0,1.5,-102>    */
       glPushMatrix();

     glMaterialfv(GL_FRONT,GL_DIFFUSE,wallAmbient);
              glScaled(50,3,1);
              glTranslated(0,1.3,-102);
             glutSolidCube2(4);
        glPopMatrix();


      /*DRAW wall AT <102,1.5,0>    */
       glPushMatrix();

      glMaterialfv(GL_FRONT,GL_DIFFUSE,wallAmbient);
              glScaled(1,3,50);
              glTranslated(102,1.3,0);
             glutSolidCube2(4);
        glPopMatrix();


       /*DRAW wall AT <-102,1.5,0>    */
       glPushMatrix();

      glMaterialfv(GL_FRONT,GL_DIFFUSE,wallAmbient);
              glScaled(1,3,50);
              glTranslated(-102,1.3,0);
             glutSolidCube2(4);
        glPopMatrix();

    }

    void drawCube(int x,int z)
    {
        glPushMatrix();
//                      glMaterialfv(GL_FRONT,GL_DIFFUSE,redAmbient);
                      glTranslated(x,0,z);
                      glutSolidCube2(4);
           glPopAttrib();
        glPopMatrix();
    }


};

class Player
{
    public :
        Player(){}

        Player(float *cameraX,float *cameraY,float *cameraZ,float *angle)
        {
            posx=cameraX;
            posy=cameraY;
            posz=cameraZ;

            this->angle=angle;
        }

        void drawTank()
        {
                    /*TANK TRANSLATION PUSH*/
            glPushMatrix();
                glTranslatef(*posx, *posy, *posz); // Translation to the camera center
                glRotatef(*angle , 0,1,0); // Rotate to correspond to the camera
                glTranslatef(0,0,3); // Offset to draw the object
                /*DRAW TOP PIECE OF TANK*/
                 glPushMatrix();
                  //TOP
                  GLfloat yellowAmbient[] ={1,1,0};
                  glMaterialfv(GL_FRONT,GL_DIFFUSE,yellowAmbient);
                  glTranslatef(0,0.5,0);
                  glutSolidCube(0.5);
                glPopMatrix();


               /*DRAW BASE OF TANK*/
               glPushMatrix();
                 glScalef(1,0.5,1);
                 glutSolidCube(1.0);
               glPopMatrix();


            /*DRAW CANNON*/
             glPushMatrix();
               glRotated(0,0,1,0);
               glTranslatef(0,0.6,-0.2);
               glScalef(1,1,3);
               GLUquadricObj *qobj = gluNewQuadric();
               gluCylinder(qobj,0.1,0.1,0.4,50,50);
             glPopMatrix();

             /*DRAW CROSSHAIR*/
             glPushMatrix();
                glTranslatef(0,0.6,0.5);
                glColor3ub(255, 255, 0);
                glLineWidth(1.0);

                glBegin(GL_LINES);
                    glColor3f(1,0,0);
                    glVertex2f(-0.2,0.6);
                    glVertex2f(0.2,0.6);
                    glVertex2f(0,0.8);
                    glVertex2f(0,0.4);
                glEnd();

             glPopMatrix();
             glPopMatrix();
        }

    private :
        float* posx;
        float* posy;
        float* posz;

        float* angle;



};

class Shooter
{
    public:
        // draw all bullets
        void drawBullet()
        {
            for(int i=0;i<bullets.size();i++)
            {
                if(bullets[i].alive)
                {
                    //DRAW BULLET
                    glPushMatrix();
                        glTranslatef(bullets[i].Position.x,bullets[i].Position.y,bullets[i].Position.z);
                        glRotatef(bullets[i].angle,0,1,0);
                        glTranslatef(0,0.3,3+0.6+0.9);
                        glutSolidSphere(0.2,50,50);
                    glPopMatrix();
                }
            }
        }

        void update()
        {
            for(int i=0;i< bullets.size();i++)
            {
                if (bullets[i].alive == true)
                {
                    bullets[i].e += 0.01;
                    float ab = M_PI*bullets[i].angle/180.0;
                    bullets[i].Position.x += 0.1*sin(ab);
                    bullets[i].Position.z += 0.1*cos(ab);
                    if (bullets[i].e  > 25 )
                    {
                        bullets[i].alive = false;
                    }
                }
            }
            for(int i=0;i< bullets.size();i++)
            {
                if (bullets[i].alive == false)
                {
                    bullets.erase(bullets.begin()+i);
                }
            }
        }

        void createNewBullet(float camerax,float cameray,float cameraz,float angle)
        {
            Tank.Position ={camerax,cameray,cameraz};
            Tank.angle=angle;
            Bullet p ={{Tank.Position.x,Tank.Position.y,Tank.Position.z},Tank.angle,0,true};
            bullets.push_back(p);
        }

    private:
        struct Vector3{
        float x,y,z;
        };

        struct Bullet {
        Vector3 Position;
        float angle,e;
        bool alive;
        };

        struct {
        Vector3 Position;
        float angle;
        } Tank;

       vector<Bullet> bullets;
};


float a;
float direction[3];
const int FPS = 30;
float rangle;
float xCord = 0.0;
float zCord = 1;
float aXCord,aZCord;
bool d=false;
float t=0;

float x_rotation=0;
float y_rotation=0;

float turn_inc;
float z_dist_at;

float tX,tY,tZ;

World world; //  The world
Player playerTank; //  player tank
Shooter shooting;  // Object for shooting





float camera[3][3] = {
            {0, 0, -z_dist_at},
            {0, 0, 0},
            {0, 1.0f, 0}
};

float lx, ly, lz;
float angle;

void resetCamera(){
		angle = 0;
		lx=0;
		lz=z_dist_at;
		camera[0][2] =  -z_dist_at;
}

//vector<snowman> v_snowman; // A vector containing all the snowmen


/* Initialize OpenGL Graphics */
void init()
{
    // Set "clearing" or background color
    glClearColor(0, 0.7, 1, 1); // White and opaque
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST); // turns on hidden surface removal so that objects behind other objects do not get displayed

    turn_inc = 0.5; // in degrees

    z_dist_at = 5.0;

    resetCamera();

    world = World(); // Construct world
    playerTank = Player(&camera[0][0], &camera[0][1], &camera[0][2],&angle);
    shooting = Shooter();
}

void setCamera(){

		//cout << angle << " lx: " << lx << " lz:" << lz << "\n";
    	// Set the camera

		gluLookAt(	camera[0][0], 1.5, camera[0][2],
    				camera[1][0], camera[1][1], camera[1][2],//
    				camera[2][0], camera[2][1], camera[2][2]  );

}



void drawObstacles()
{

    //DRAW 1ST OBSTACLE
                  world.drawCube(-3,3);
                  world.drawCube(-5,3);
                  world.drawCube(-7,3);
                  world.drawCube(-9,3);

                  world.drawCube(-3,1);
                  world.drawCube(-3,3);
                  world.drawCube(-3,5);
                  //----------------//







                  //DRAW 2ND OBSTACLE
                  world.drawCube(3,3);
                  world.drawCube(5,3);
                  world.drawCube(7,3);
                  world.drawCube(9,3);

                  world.drawCube(3,1);
                  world.drawCube(3,3);
                  world.drawCube(3,5);
                  //----------------//

                  //DRAW 3RD OBSTACLE
                  world.drawCube(-11,5);
                  world.drawCube(-13,5);
                  world.drawCube(-15,5);
                  world.drawCube(-17,5);

                  world.drawCube(-13,7);
                  world.drawCube(-13,9);
                  world.drawCube(-13,11);
                  //----------------//


                  world.drawCube(75,81);
                  world.drawCube(79,81);
                  world.drawCube(81,81);
                  world.drawCube(83,81);
                  world.drawCube(85,81);

                  world.drawCube(87,83);
                  world.drawCube(89,85);
                  world.drawCube(91,87);


                  //--------------//
                  world.drawCube(-75,81);
                  world.drawCube(-79,81);
                  world.drawCube(-81,81);
                  world.drawCube(-83,81);
                  world.drawCube(-85,81);

                  world.drawCube(-87,83);
                  world.drawCube(-89,85);
                  world.drawCube(-91,87);
                  //--------------//



                  //--------------//
                  world.drawCube(77,-81);
                  world.drawCube(79,81);
                  world.drawCube(81,81);
                  world.drawCube(83,81);
                  world.drawCube(85,81);

                  world.drawCube(87,83);
                  world.drawCube(89,85);
                  world.drawCube(91,87);
                  //--------------//


}
void render()
{

    // GL_DEPTH_BUFFER_BIT - resets the depth test values for hidden surface removal
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Reset transformations
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    // Set the camera
    setCamera();

              //DRAW WORLD
                 world.drawWorld();

                 drawObstacles();

                 //renderBitMapString(-2.6,2.5,0,GLUT_BITMAP_HELVETICA_18,"LIVES: 5");
                 //renderBitMapString(0,2.5,0,GLUT_BITMAP_HELVETICA_18,"KILLS: 3");
                 //renderBitMapString(2.6,2.5,0,GLUT_BITMAP_HELVETICA_18,"SCORE: 250");

                  //glutSolidCube2(4);




    playerTank.drawTank();

    shooting.drawBullet();


glutSwapBuffers();   // ******** DO NOT FORGET THIS **********
}


void update()
{
    shooting.update();

    glutPostRedisplay();
}

/* Handler for window-repaint event. Call back when the window first appears and
   whenever the window needs to be re-painted. */
void display()
{
    render();
}

/* Handler for window re-size event. Called back when the window first appears and
   whenever the window is re-sized with its new width and height */

void reshape(int w, int h)
{

    // Prevent a divide by zero, when window is too short
    // (you cant make a window of zero width).
    if(h == 0)	h = 1;

    GLfloat ratio = 1.0f * (GLfloat)w / (GLfloat)h;

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);

    // Reset the coordinate system before modifying
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Set the clipping volume
    gluPerspective(45, ratio, 0.1, 1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();



}

void processNormalKeys(unsigned char key, int x, int y) {

	switch (key) {
		case 27 :  exit(0); break;
		case ' ':  shooting.createNewBullet(camera[0][0],camera[0][1],camera[0][2],angle); break;
    }
    glutPostRedisplay();
}




void inputKey(int key, int ix, int iy) {
    float  x, z;
	switch (key) {
		case GLUT_KEY_LEFT :
        	angle += turn_inc;
			a = M_PI*angle/180.0;
			lx = z_dist_at *sin(a);
			lz = z_dist_at *cos(a);
			camera[1][0]=camera[0][0]+lx;
			camera[1][2]=camera[0][2]+lz;
            break;

		case GLUT_KEY_RIGHT :
           	angle -= turn_inc;
			a = M_PI*angle/180.0;
			lx = z_dist_at *sin(a);
			lz = z_dist_at *cos(a);
			camera[1][0]=camera[0][0]+lx;
			camera[1][2]=camera[0][2]+lz;
		    break;

		case GLUT_KEY_UP :
		    a = M_PI*angle/180.0;
			x =  sin(a);
			z = cos(a);
        	camera[0][0] += x; // move x by
            camera[0][2] += z;
        	camera[1][0] += x; // move x by
            camera[1][2] += z;
            xCord += x;
            zCord += z;
		    break;
		case GLUT_KEY_DOWN :
		    a = M_PI*angle/180.0;
			x =  sin(a);
			z = cos(a);
        	camera[0][0] -= x; // move x by
            camera[0][2] -= z;
        	camera[1][0] -= x; // move x by
            camera[1][2] -= z;
            xCord -= x;
            zCord -= z;
            break;
	}

    glutPostRedisplay();
}



/* Main function: GLUT runs as a console application starting at main() */
char* filename = "C:\\Users\\andile\\315\\testTexture\\redBricks.bmp";
int main(int argc, char** argv)
{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(640,480);   // Set the window's initial width & height - non-square
    glutInitWindowPosition(100, 100); // Position the window's initial top-left corner
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_DEPTH|GLUT_RGB);
    glutCreateWindow("MBAYIMBAYI");  // Create window with the given title
    loadTextureFromFile(filename);
                          // Our own OpenGL initialization

    glutDisplayFunc(display);       // Register callback handler for window re-paint event
    glutIdleFunc(update);
    glutReshapeFunc(reshape);       // Register callback handler for window re-size event

	glutKeyboardFunc(processNormalKeys);
	glutSpecialFunc(inputKey);

    //glutTimerFunc(1000,myTimer,FPS);
    init();
    glutMainLoop();                 // Enter the infinite event-processing loop
    return 0;
}
