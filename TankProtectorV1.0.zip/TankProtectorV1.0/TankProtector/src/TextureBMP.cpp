#include "TextureBMP.h"

TextureBMP::TextureBMP()
{
    //ctor
}

TextureBMP::~TextureBMP()
{
    //dtor
}
