#ifndef COLLISION_H
#define COLLISION_H
#include "Snowman.h"
#include "Flower.h"
#include "WindMill.h"

class collision
{
    public:
        collision();
        collision(double distance, double distance1);
        void detectCollision();
       // double calDistance();
    protected:

    private:
        double distance;
        double distance1;

        //Sprinkler spr;
        //Person pers;


};

#endif // COLLISION_H
