#ifndef BULLET_H
#define BULLET_H


class Bullet
{
    public:
        Bullet();
        virtual ~Bullet();
    protected:
    private:
};

#endif // BULLET_H
