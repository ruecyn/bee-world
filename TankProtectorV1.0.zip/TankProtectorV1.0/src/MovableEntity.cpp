#include "MovableEntity.h"
#include <math.h>
#include <iostream>

MovableEntity::MovableEntity(float x,float y,float z,float r) : Entity(x,y,z,r)
{}

MovableEntity::MovableEntity():Entity(0,0,0,0)
{}

MovableEntity::~MovableEntity()
{}

/* Check if Entity collide with Entity e*/
bool MovableEntity::checkCollision(Entity *e)
{
    float distance = sqrt(pow(pos.x - e->getPosition().x, 2) + pow(pos.z - e->getPosition().z, 2));
   // std::cout << distance << " | "<< pos.x << " "<< pos.z<< "::" << e->getPosition().x << " "<<e->getPosition().z <<std::endl;
    return (distance < Eradius + e->getRadius());
}

/* check if entity alive */
bool MovableEntity::isAlive()
{
    return alive;
}

/* make entity live */
void MovableEntity::born()
{
    alive = true;
}

/* kill this entity */
void MovableEntity::kill()
{
    alive = false;
}

/* set new Position of movable entity */
void MovableEntity::setPosition(float x,float y,float z)
{
    pos.x = x;
    pos.y = y;
    pos.z = z;

}
