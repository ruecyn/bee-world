#include "collision.h"
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <iostream>
#include "math.h"
#include "Snowman.h"
#include "Flower.h"
#include "WindMill.h"

collision::collision()
{
    //ctor
}
collision::collision(double distance,double distance1){
    this->distance1=distance1;
    this->distance=distance;
}

/*
double collision::calDistance(Obj o){
double dist1= pow((o.x-b.x),2)+((o.y-b.y),2)+((o.z-b.z),2);
distance=sqrt(dist1);
return distance;
}*/
void collision::detectCollision(){
    Snowman s;
    Flower flower;
    WindMill windmill;
    double dist1=pow((windmill.x-s.x),2)+((windmill.y-s.y),2)+((windmill.z-s.z),2);
    distance=sqrt(dist1);
    double dist2=pow((flower.x-s.x),2)+((flower.y-s.y),2)+((flower.z-s.z),2);
    distance1=sqrt(dist2);
 if(distance-s.radius==0){
    s.x--;
    //s.moveBeeBackward();
}

else if(distance-s.radius==0){
  //  s.moveBeeBackward();
   s.x--;
}

else{
    s.moveBeeForward();
}

}
